#include <blitz/array.h>

BZ_USING_NAMESPACE(blitz)

int module2()
{
    BZ_USING_NAMESPACE(blitz::tensor)

    Array<int,1> A(4);
    A = pow2(i);
    return 0;
}

