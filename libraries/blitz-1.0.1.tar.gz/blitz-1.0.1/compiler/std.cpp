#include <iostream>
#include <map>
#include <iomanip>

#ifndef BZ_NO_NAMESPACES
using namespace std;
#endif

int main()
{
    return 0;
}

