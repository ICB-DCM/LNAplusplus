template<typename T>
class X {
public:
    X() { }
};

int main()
{
    X<float> z;
    return 0;
}

