// complex<T> class

#include <complex>

#ifndef BZ_NO_NAMESPACES
using namespace std;
#endif

int main()
{
    complex<float> a;
    complex<double> b;
    return 0;
}

